//
//  ZuulRemoteViewController.m
//  ZuulRemote
//
//  Created by Benoît Garbinato on 21/4/09.
//  Copyright Université de Lausanne 2009. All rights reserved.
//

#import "ZuulRemoteViewController.h"
#import "ZuulRemoteAppDelegate.h"

@implementation ZuulRemoteViewController

@synthesize currentPosition;
@synthesize	currentRoom;
@synthesize commandField;
@synthesize northButton;
@synthesize southButton;
@synthesize eastButton;
@synthesize westButton;
@synthesize allButtons;


- (IBAction) move: (id)sender {
	// to be implemented...
    NSLog(@"User clicked %@", ((UIButton *)sender).currentTitle);
    appDelegate= (ZuulRemoteAppDelegate*)[UIApplication sharedApplication].delegate;
    [appDelegate sendDirection:((UIButton *)sender).currentTitle];
}

- (IBAction)textFieldDidEndEditing:(UITextField *)textField {
    NSLog(@"command %@",textField);
    appDelegate= (ZuulRemoteAppDelegate*)[UIApplication sharedApplication].delegate;
    [appDelegate sendMessage:textField.text];
    [commandField setText:@"TEST"];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
     NSLog(@"viewDidLoad");
	appDelegate= (ZuulRemoteAppDelegate*)[UIApplication sharedApplication].delegate;
    //Allocation de memoire et init des buttons
    southButton = [[UIButton alloc] init];
    northButton = [[UIButton alloc] init];
    eastButton = [[UIButton alloc] init];
    westButton = [[UIButton alloc] init];
	allButtons= [NSMutableArray array];
	[allButtons retain];
	[allButtons addObject: southButton];
	[allButtons addObject: northButton];	
	[allButtons addObject: eastButton];
	[allButtons addObject: westButton];
    NSLog(@"END");
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [allButtons release];
    [southButton release];
    [northButton release];
    [eastButton release];
    [westButton release];
    [super dealloc];
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
	if (theTextField == commandField){
		[commandField resignFirstResponder];
	}
	return YES;
}

@end
