//
//  main.m
//  ZuulRemote
//
//  Created by Benoît Garbinato on 21/4/09.
//  Copyright Université de Lausanne 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
