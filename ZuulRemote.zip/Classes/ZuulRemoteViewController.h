//
//  ZuulRemoteViewController.h
//  ZuulRemote
//
//  Created by Benoît Garbinato on 21/4/09.
//  Copyright Université de Lausanne 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZuulRemoteAppDelegate;

@interface ZuulRemoteViewController : UIViewController <UITextFieldDelegate> {
	IBOutlet UILabel*   currentPosition;
	IBOutlet UIImageView*  currentRoom;
	IBOutlet UITextField*  commandField;
	IBOutlet UIButton*  northButton;
	IBOutlet UIButton*  southButton;
	IBOutlet UIButton*  eastButton;
	IBOutlet UIButton*  westButton;
	ZuulRemoteAppDelegate* appDelegate;
	NSMutableArray* allButtons;
}

@property (nonatomic,retain) UITextField *commandField;
@property (nonatomic,retain) UILabel *currentPosition;
@property (nonatomic,retain) UIImageView *currentRoom;
@property (nonatomic,retain) UIButton *northButton;
@property (nonatomic,retain) UIButton *southButton;
@property (nonatomic,retain) UIButton *eastButton;
@property (nonatomic,retain) UIButton *westButton;
@property (nonatomic,retain) NSMutableArray *allButtons;


- (IBAction) move: (id)sender;

@end

