//
//  ZuulRemoteAppDelegate.h
//  ZuulRemote
//
//  Created by Benoît Garbinato on 21/4/09.
//  Copyright Université de Lausanne 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZuulRemoteViewController;

@interface ZuulRemoteAppDelegate : NSObject <UIApplicationDelegate, NSNetServiceDelegate, NSStreamDelegate> {
    UIWindow *window;
    ZuulRemoteViewController *viewController;
	NSInputStream *istream;
	NSMutableData *inData; // data read from server
	int bytesRead;	
	
	NSOutputStream *ostream;
	NSMutableData *outData; // data to be sent to server
	int outIndex; // pointer of what remains to be sent
	BOOL connected;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ZuulRemoteViewController *viewController;

- (void) sendDirection: (NSString*) direction;
- (NSString*) receiveLocation;

- (void) sendMessage: (NSString *) message;
- (void) writeDataTo: (NSOutputStream*) outStream;



// NSNetService delegate methods
- (void) netServiceDidResolveAddress: (NSNetService *)netService;
- (void) netService: (NSNetService *)netService
	  didNotResolve: (NSDictionary *)errorDict;
@end

