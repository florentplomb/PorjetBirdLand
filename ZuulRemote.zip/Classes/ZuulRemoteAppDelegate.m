//
//  ZuulRemoteAppDelegate.m
//  ZuulRemote
//
//  Created by Benoît Garbinato on 21/4/09.
//  Copyright Université de Lausanne 2009. All rights reserved.
//

#import "ZuulRemoteAppDelegate.h"
#import "ZuulRemoteViewController.h"


#define SERVICE_PORT  4444
#define BUFFER_SIZE   512	
#define SERVICE_NAME  @"oop-zuul2014"


@implementation ZuulRemoteAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    //[window addSubview:viewController.view];
    [window setRootViewController:viewController];
    [window makeKeyAndVisible];
	
	// Connect to Zuul game service
	NSNetService* gameService= [[NSNetService alloc] initWithDomain:@"local." type:@"_witap._tcp." name: SERVICE_NAME port: SERVICE_PORT];
	[gameService setDelegate: self];
	[gameService resolveWithTimeout: 10.0];
	
	// Create a mutable data object for sending data to the server
	outData = [NSMutableData dataWithCapacity: BUFFER_SIZE];
	[outData retain];
	outIndex= 0;
	connected= NO;
	
	inData= nil;
	bytesRead= 0;
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

- (void) sendDirection: (NSString*) direction {
    NSLog(@"Direction %@",direction);
	NSString* newDirection = [[NSString alloc] initWithFormat:@"go %@",direction];
	[self sendMessage: newDirection];
}

- (NSString*) receiveLocation {
	return nil;
}

// Sent when addresses are resolved
- (void) netServiceDidResolveAddress: (NSNetService *)netService {
	NSLog(@"-> success: service %@ resolved", netService.name);
	NSArray *netAddresses= netService.addresses;
	
	NSLog(@"-> Number of adresses for %@ is %d:", netService.name, netAddresses.count);
	for (NSData *data in netAddresses) {
		NSLog(@"   -> data is %@", data.description);
	}
	NSLog(@"-> The server port is %d", netService.port);
	
	// This code does not seem to work. Check how to really establish a connection
	// to the (Java) server, as it works fine from a Java client
	if (netService.port > 0) {
		[netService getInputStream: &istream outputStream: &ostream];
		
		if (istream && ostream) {
			istream.delegate = self;
			[istream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
			[istream open];
			ostream.delegate = self;
			[ostream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
			[ostream open];
		}
		else
			NSLog(@"-> Connection to port %d failed", netService.port);
	}
}

// Sent if resolution fails
- (void) netService: (NSNetService *)netService
	  didNotResolve: (NSDictionary *) errorDict {
	NSLog(@"-> failure: service %@ not resolved", netService.name);
	NSLog(@"-> Possible errors are %@", [errorDict description]);
}


- (void) sendMessage: (NSString *) message {
	NSLog(@"I am about to send \"%@\"", message);
	NSString* realMsg= [NSString stringWithFormat:  @"%@\n", message];
	[outData setData: [realMsg dataUsingEncoding:NSUTF8StringEncoding]];
	outIndex= 0;
	[self writeDataTo: ostream];
}

- (void) writeDataTo: (NSOutputStream*) outStream {
	uint8_t *outBytes= (uint8_t*) [outData mutableBytes];
	outBytes += outIndex;
	int data_len= [outData length];
	unsigned int len= ((data_len - outIndex >= BUFFER_SIZE) ? BUFFER_SIZE : (data_len - outIndex));
	uint8_t buf[len];
	memcpy(buf,outBytes,len);
	
	if (len > 0) {
		NSLog(@"I just sent \"%@\" to the server...", [[NSString alloc] initWithBytes: buf length: len encoding: NSUTF8StringEncoding]);
		len= [outStream write: (const uint8_t*) buf maxLength: len];
		outIndex += len;
	}	
}
@end

@implementation ZuulRemoteAppDelegate (NSStreamDelegate)

- (void) stream:(NSStream*)stream handleEvent:(NSStreamEvent)eventCode
{
	UIAlertView* alertView;
	switch(eventCode) {
		case NSStreamEventOpenCompleted:
		{
			NSString* kind= @"IN";
			if ([stream isKindOfClass: [NSOutputStream class]])
				kind= @"OUT";
			NSLog(@"-> Connection %@ successfully established", kind);
			
			if (istream && ostream && !connected) {
				alertView = [[UIAlertView alloc] initWithTitle:@"Your can now remotely control the World of Zuul!" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Continue", nil];
				[alertView show];
				[alertView release];
				connected= YES;
			}
			break;
		}		
		case NSStreamEventHasSpaceAvailable:
		{			
			NSOutputStream* outStream= (NSOutputStream*) stream;
			[self writeDataTo: outStream];
			break;
		}	
		case NSStreamEventHasBytesAvailable:
		{
            if(!inData) {
                inData = [[NSMutableData data] retain];
            }
            uint8_t buf[BUFFER_SIZE];
            unsigned int len = 0;
            len = [(NSInputStream *)stream read:buf maxLength:BUFFER_SIZE];
            if(len) {
                [inData appendBytes:(const void *)buf length:len];
                bytesRead= bytesRead +len;
            } else {
                NSLog(@"no buffer!");
            }
			
			NSString* response= [[NSString alloc] initWithData: inData encoding: NSUTF8StringEncoding];
			
			if ([response hasSuffix: @"\n"]) {
				response= [response substringToIndex: [response length] - 1];
				NSArray* infos= [response componentsSeparatedByString: @"/"];
				NSString* nextRoom= [[NSString alloc] initWithFormat: @"Your current position is %@",[infos objectAtIndex: 0]];
				NSString* exits= [infos objectAtIndex: 1];
				NSString* roomName= [infos objectAtIndex: 4];
				NSLog(@"Next room is %@ -%@- with exits: %@", nextRoom, roomName, exits);
				
				// Set the new room
				viewController.currentPosition.text= nextRoom;
				viewController.currentRoom.image = [UIImage imageNamed:roomName];
				
				// Enable and disable buttons based on  exits
				NSArray* allExits= [exits componentsSeparatedByString: @","];
					UIButton* button;
					for(button in viewController.allButtons) {
						if([allExits containsObject: button.currentTitle])
							button.hidden= NO;
						else button.hidden= YES;
				}
				
				inData= nil;
			}
            break;
		}
			case NSStreamEventNone:
        {
            break;
        }
        
        case NSStreamEventErrorOccurred:
        {
            break;
        }
            
        case NSStreamEventEndEncountered:
        {
            break;
        }
	}
}
@end


